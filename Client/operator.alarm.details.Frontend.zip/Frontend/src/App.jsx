import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'; 

import PanoraGuardDashboard from './components/PanoraGuardDashboard';
import OperatorPage from './pages/OperatorPage';
import AlarmDetailPage from './pages/AlarmDetailPage';
import LiveFeedPage from './pages/LiveFeedPage'; 

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<OperatorPage />} />
        <Route path="/details" element={<PanoraGuardDashboard />} />
        <Route path="/alert-details" element={<AlarmDetailPage />} />
        <Route path="/live-feed" element={<LiveFeedPage />} />
      </Routes>
    </Router>
  );
};

export default App;
